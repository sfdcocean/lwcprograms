import { LightningElement,track } from 'lwc';

export default class Hellopkg extends LightningElement {
    @track msg='hello unlockedpkg';
}